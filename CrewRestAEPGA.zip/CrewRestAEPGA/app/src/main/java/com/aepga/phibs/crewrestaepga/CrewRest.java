package com.aepga.phibs.crewrestaepga;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.view.View;
import java.util.Calendar;
import android.app.TimePickerDialog;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;

public class CrewRest extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    SharedPreferences prefs ;
    ImageView imageNocturno, imageCircadiano, imageViewHelpNocturno, imageViewHelpRefTime, imageExtension, imageViewHelpExtension, imageViewHelpMaxDuty, imageViewHelpMaxDutyAE;
    TextView calcosVal, dutyVal, dutyMaxVal, dutyMaxValAE, dutyMaxBlock, dutyMaxBlockAE, textExtraCrew, calcosOut, calcosIn, extraCrew, textNocturno;// nextReport;
    Button calcDescanso, calcDutyMax;
    Switch switchBaseOut, switchBaseIn, switchExtraCrew, switchDhcBase;
    Spinner sectors;
    double horasI, horasO, minutosO, minutosI, dutyStart,dutyFinish,dutyFinDHC, calcosO, calcosI, duty, dutyMin, descanso, saida, saidaMin;// saidaNextMin;
    double psvMax, psvMaxAE, psvMaxMin, psvMaxMinAE, descontoPSV, horasDhc, minutosDhc, calcosDhc, dutyMaxCalcos, dutyMaxCalcosAE, dutyMaxCalcosM, dutyMaxCalcosMAE; //saidaNextReport;
    Integer dutyHora, saidaHora, psvMaxHora, psvMaxHoraAE, nsectores, dutyMaxCalcosH, dutyMaxCalcosHAE;// saidaNextHora;
    String sectores;
    boolean isShowAgain=true;
    boolean accepted=false;
    CheckBox dialogcb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crew_rest);
        calcosOut = (TextView) findViewById(R.id.calcosOut);
        calcosIn = (TextView) findViewById(R.id.calcosIn);
        extraCrew = (TextView) findViewById(R.id.extraCrew);
        calcosVal = (TextView) findViewById(R.id.calcosVal);
        dutyVal = (TextView) findViewById(R.id.dutyVal);
        dutyMaxVal = (TextView) findViewById(R.id.dutyMaxVal);
        dutyMaxBlock = (TextView) findViewById(R.id.dutyMaxBlock);
        dutyMaxBlockAE = (TextView) findViewById(R.id.dutyMaxBlockAE);
        calcDescanso = (Button) findViewById(R.id.calcDescanso);
        calcDutyMax = (Button) findViewById(R.id.calcDutyMax);
        switchBaseIn = (Switch) findViewById(R.id.switchBaseIn);
        switchBaseOut = (Switch) findViewById(R.id.switchBaseOut);
        switchExtraCrew = (Switch) findViewById(R.id.switchExtraCrew);
        switchDhcBase = (Switch) findViewById(R.id.switchDhcBase);
        sectors = (Spinner) findViewById(R.id.sectors);
        textExtraCrew = (TextView) findViewById(R.id.textExtraCrew);
        imageNocturno = (ImageView) findViewById(R.id.imageNocturno);
        imageCircadiano = (ImageView) findViewById(R.id.imageCircadiano);
        imageExtension = (ImageView) findViewById(R.id.imageExtension);
        imageViewHelpNocturno = (ImageView) findViewById(R.id.imageViewHelpNocturno);
        imageViewHelpRefTime = (ImageView) findViewById(R.id.imageViewHelpRefTime);
        imageViewHelpExtension = (ImageView) findViewById(R.id.imageViewHelpExtension);
        imageViewHelpMaxDuty = (ImageView) findViewById(R.id.imageViewHelpMaxDuty);
        imageViewHelpMaxDutyAE = (ImageView) findViewById(R.id.imageViewHelpMaxDutyAE);
        calcosO = 0;
        calcosI = 0;
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.numbOfSectors, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sectors.setAdapter(adapter);
        sectors.setOnItemSelectedListener(this);
        // Mostrar Disclaimer
        prefs = getSharedPreferences("detail", MODE_PRIVATE);
        boolean isshowagain =prefs.getBoolean("show_again", true);
        if(isshowagain)
            showdialog();

        calcosOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                final int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(CrewRest.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        calcosOut.setText(String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute));
                        horasO = selectedHour;
                        minutosO = selectedMinute;
                        calcosO = horasO + (minutosO / 60);

                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Off Blocks");
                mTimePicker.show();
            }

        });

        calcosIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(CrewRest.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        calcosIn.setText(String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute)); //String format usado para ter dois digitos
                        horasI = selectedHour;
                        minutosI = selectedMinute;
                        calcosI = horasI + (minutosI / 60);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("On Blocks");
                mTimePicker.show();

            }
        });

        extraCrew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(CrewRest.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        extraCrew.setText(String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute)); //String format usado para ter dois digitos
                        horasDhc = selectedHour;
                        minutosDhc = selectedMinute;
                        calcosDhc = horasDhc + (minutosDhc / 60);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Hora Dhc");
                mTimePicker.show();
            }
        });

        switchExtraCrew.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (switchExtraCrew.isChecked()) {
                    extraCrew.setVisibility(View.VISIBLE);
                    textExtraCrew.setVisibility(View.VISIBLE);
                    switchDhcBase.setVisibility(View.VISIBLE);
                } else {
                    extraCrew.setVisibility(View.INVISIBLE);
                    textExtraCrew.setVisibility(View.INVISIBLE);
                    switchDhcBase.setVisibility(View.INVISIBLE);
                }
            }
        });

        calcDescanso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (switchBaseOut.isChecked()) {
                    dutyStart = Math.round((calcosO - 1) * 100);
                    dutyStart = dutyStart / 100;
                } else {
                    dutyStart = Math.round((calcosO - 0.75) * 100);
                    dutyStart = dutyStart / 100;
                }
                dutyFinish = Math.round((calcosI + 0.5) * 100);
                dutyFinish = dutyFinish / 100;
                if (switchExtraCrew.isChecked()) {
                    dutyFinDHC = Math.round((calcosDhc + 0.5)* 100);
                    dutyFinDHC = dutyFinDHC / 100;
                }
                // Nocturno
                if ((dutyStart<6.5)||(dutyStart>=23)) {
                    imageNocturno.setBackgroundResource(android.R.drawable.checkbox_on_background);
                }else{
                    if ((dutyFinish<6.5)||(dutyFinish>=23)||(dutyFinish<dutyStart)){
                        imageNocturno.setBackgroundResource(android.R.drawable.checkbox_on_background);
                    }else {
                        if (switchExtraCrew.isChecked()) {
                            if ((dutyFinDHC < 6.5) || (dutyFinDHC >= 23)||(dutyFinDHC<dutyFinish)) {
                                imageNocturno.setBackgroundResource(android.R.drawable.checkbox_on_background);
                            } else {
                                imageNocturno.setBackgroundResource(android.R.drawable.checkbox_off_background);
                            }
                        }else{
                            imageNocturno.setBackgroundResource(android.R.drawable.checkbox_off_background);
                        }
                    }
                }
                //Circadiano
                if ((dutyStart <= 6)&&(dutyStart>=2)) { //Por DL 6:00 inclusivé <= em vez de <
                    imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_on_background);
                }else{
                    if ((dutyFinish <= 6)&&(dutyFinish>=2)){
                        imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_on_background);
                    }else {
                        if ((dutyFinish> 6)&&(dutyFinish<dutyStart)){ //Por DL 6:00 inclusivé > em vez de >=
                            imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_on_background);
                        }else {
                            if (switchExtraCrew.isChecked()) {
                                if ((dutyFinDHC <= 6) && (dutyFinDHC >= 2)) {
                                    imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_on_background);
                                } else {
                                    if ((dutyFinDHC > 6) && (dutyFinDHC < dutyFinish )) {
                                        imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_on_background);
                                    } else {
                                        imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_off_background);
                                    }
                                }
                            } else {
                                imageCircadiano.setBackgroundResource(android.R.drawable.checkbox_off_background);
                            }
                        }
                    }
                }
                if (switchExtraCrew.isChecked()) {
                    if (calcosO > calcosI) {
                        calcosI = calcosI + 24;
                        calcosDhc = calcosDhc + 24;
                    } else {
                        if (calcosDhc < calcosI) {
                            calcosDhc = calcosDhc + 24;
                        }
                    }
                    if (switchBaseOut.isChecked()) {
                        duty = (calcosDhc - calcosI) / 2 + (calcosI - (calcosO - 1));
                    } else {
                        duty = (calcosDhc - calcosI) / 2 + (calcosI - (calcosO - 0.75));
                    }
                    if (switchDhcBase.isChecked()) {
                        if ((duty * 1.25) > 12) {
                            descanso = (duty * 1.25) + 4;
                        } else {
                            descanso = 16;
                        }
                    } else {
                        if (duty > 9) {
                            descanso = duty + 3;
                        } else {
                            descanso = 12;
                        }
                    }
                    if (calcosDhc > 24) {
                        calcosDhc = calcosDhc - 24;
                    }
                    saida = calcosDhc + descanso;
                } else {
                    if (calcosO > calcosI) {
                        calcosI = calcosI + 24;
                    }
                    if (switchBaseOut.isChecked()) {
                        duty = calcosI - (calcosO - 1);
                    } else {
                        duty = calcosI - (calcosO - 0.75);
                    }
                    if (switchBaseIn.isChecked()) {
                        if ((duty * 1.25) > 12) {
                            descanso = (duty * 1.25) + 4;
                        } else {
                            descanso = 16;
                        }
                    } else {
                        if (duty > 9) {
                            descanso = duty + 3;
                        } else {
                            descanso = 12;
                        }
                    }
                    if (calcosI > 24) {
                        calcosI = calcosI - 24;
                    }
                    saida = calcosI + descanso;
                }
                if (saida > 24) {
                    saidaHora = (int) saida - 24;
                } else {
                    saidaHora = (int) saida;
                }
                saidaMin = Math.round((saida - (int) saida) * 60);
                calcosVal.setText(String.format("%02d", saidaHora) + ":" + String.format("%02d", (int) saidaMin));
                calcosVal.setVisibility(View.VISIBLE);
                dutyHora = (int) duty;
                dutyMin = Math.round((duty - (int) duty) * 60); // Math.ceil usado para arredondar
                if (dutyMin == 60) {    // Por causa dos arredondamentos em DHC
                    dutyMin = 0;        // Retornava 60 minutos
                    dutyHora = dutyHora + 1;
                }
                dutyVal.setText(String.format("%02d", dutyHora) + ":" + String.format("%02d", (int) dutyMin));
                dutyVal.setVisibility(View.VISIBLE);
            }
        });

        imageViewHelpNocturno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(CrewRest.this).create();
                alertDialog.setTitle("Decreto de Lei 139/2004");
                alertDialog.setMessage(Html.fromHtml("1 — Um tripulante não pode efectuar"+"<b>"+" mais de dois "
                        +"</b>" + "períodos de serviço nocturno "+"<b>"+"consecutivos."+"</b>" + "<br>"+
                        "2 — No caso de serem efectuados dois períodos consecutivos " +
                        "de serviço nocturno, "+"<b>"+"apenas um"+"</b>"+" deles pode " +
                        "incluir, no todo ou em parte, "+"<b>"+"o período crítico do ritmo circadiano."+"</b>"+"<br>" +
                        "3 — Em caso de alteração operacional imprevista, um" +
                        " tripulante pode completar o segundo período de serviço " +
                        "nocturno consecutivo para regresso à base, sem sujeição " +
                        "à limitação prevista no número anterior." + "<br>"+
                        "4 — Um tripulante não pode efectuar "+"<b>"+"mais de três" + "</b>"+
                        " períodos de serviço nocturno "+"<b>"+"numa semana"+"</b>"+", dos quais "+"<b>"+"dois " +"</b>"+
                        "podem ser "+"<b>"+"consecutivos se forem antecedidos ou" +
                        " seguidos de uma folga semanal."+"</b>"+"<br>"+"5 — Em caso de alteração operacional imprevista que " +
                        "ocorra fora da base e implique um atraso no voo, "
                        +"abrangendo o período de serviço nocturno, não se aplicam " +
                        "as limitações previstas no número anterior." + "<br>"+
                        "6 — As situações excepcionais previstas nos n.3 e 5 " +
                        "não podem ser cumuladas."));
                // Alert dialog button
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Alert dialog action goes here
                                // onClick button code here
                                dialog.dismiss();// use dismiss to cancel alert dialog
                            }
                        });
                alertDialog.show();
            }
        });

        imageViewHelpRefTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(CrewRest.this).create();
                alertDialog.setTitle("Reference Time");
                alertDialog.setMessage(Html.fromHtml("<b>"+"Decreto de Lei 139/2004 Artigo 2º n)"+"</b>"+"<br>"
                        + "<b>"+"Hora local "+"</b>"+"— Período de sessenta minutos, " +
                        "reportado ao "+"<b>"+"local da base"+"</b>"+", até ao limite de " +
                        "quarenta e oito horas, a contar da partida desse " +
                        "local, e reportado ao local de origem do voo " +
                        "após decorridas quarenta e oito horas da partida " +
                        "do local da base."));
                // Alert dialog button
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Alert dialog action goes here
                                // onClick button code here
                                dialog.dismiss();// use dismiss to cancel alert dialog
                            }
                        });
                alertDialog.show();
            }
        });
        /* Calculates Maximum Duty */
        calcDutyMax.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(CrewRest.this,"A hora de Calços é a hora de origem LT", Toast.LENGTH_LONG).show();
                imageExtension.setBackgroundResource(android.R.drawable.checkbox_off_background);
                if (switchBaseOut.isChecked()) {
                    dutyStart = Math.round((calcosO - 1) * 100);
                    dutyStart = dutyStart / 100;
                } else {
                    dutyStart = Math.round((calcosO - 0.75) * 100);
                    dutyStart = dutyStart / 100;
                }
                if ((dutyStart <= 4.98) || (dutyStart > 17)) {
                    psvMax = 11;
//                    Toast.makeText(CrewRest.this,
//                            "Extensão do Duty não é permitida", Toast.LENGTH_LONG).show();
//                    imageExtension.setBackgroundResource(android.R.drawable.checkbox_on_background);
                } else {
                    if ((dutyStart >= 5) && (dutyStart <= 5.98)) {
                        if ((dutyStart >= 5) && (dutyStart <= 5.23)) {
                            psvMax = 12;
                        } else {
                            descontoPSV = Math.floor((dutyStart - 5) * 4f) / 4f; // arredondamento aos 15 abaixo
                            psvMax = 12 + descontoPSV;                           // contando a totalidade do PSV
                        }
                    } else {
                        if ((dutyStart >= 6) && (dutyStart <= 13.48)) {
                            psvMax = 13;
                        } else {
                            descontoPSV = Math.ceil(((dutyStart - 13.49) / 2) * 4f) / 4f; // arredondamento aos 15 acima
                            psvMax = 13 - descontoPSV;                                    // contando metade do PSV
                        }
                    }

                }
                if (((dutyStart <= 6.23) || (dutyStart >= 13.5)) && (nsectores+2 >= 5) ){
                    imageExtension.setBackgroundResource(android.R.drawable.checkbox_on_background);
                }else {
                    if (((dutyStart <= 6.23) || (dutyStart >= 15.5)) && (nsectores+2 >= 3)) {
                        imageExtension.setBackgroundResource(android.R.drawable.checkbox_on_background);
                    } else {
                        if (((dutyStart <= 6.23) || (dutyStart >= 19.0)) && (nsectores+2 >= 1)) {
                            imageExtension.setBackgroundResource(android.R.drawable.checkbox_on_background);
                        }
                    }
                }
                psvMax = psvMax - nsectores * 0.5; //retira 30 minutos por cada sector acima dos 2
                if ((dutyStart <= 6)&&(dutyStart>=2)) {
                    psvMaxAE = 7;
                    if (nsectores+2 > 3){
                        Toast.makeText(CrewRest.this,
                                "Limitado a 3 sectores por AE", Toast.LENGTH_LONG).show();
                    }

                }else{
                    psvMaxAE = psvMax;
                }
                psvMaxHora = (int) psvMax;
                psvMaxHoraAE = (int) psvMaxAE;
                psvMaxMin = Math.round((psvMax - (int) psvMax) * 60);
                psvMaxMinAE = Math.round((psvMaxAE - (int) psvMaxAE) * 60);
                if (switchBaseOut.isChecked()) {
                    dutyMaxCalcos = calcosO - 1 + psvMax;
                    dutyMaxCalcosAE = calcosO - 1 + psvMaxAE;
                } else {
                    dutyMaxCalcos = calcosO - 0.75 + psvMax;
                    dutyMaxCalcosAE = calcosO - 0.75 + psvMaxAE;
                }
                if (dutyMaxCalcos > 24) {
                    dutyMaxCalcos = dutyMaxCalcos - 24;
                }
                if (dutyMaxCalcosAE > 24) {
                    dutyMaxCalcosAE = dutyMaxCalcosAE - 24;
                }
                dutyMaxCalcosH = (int) dutyMaxCalcos;
                dutyMaxCalcosHAE = (int) dutyMaxCalcosAE;
                dutyMaxCalcosM = Math.round((dutyMaxCalcos - (int) dutyMaxCalcos) * 60);
                dutyMaxCalcosMAE = Math.round((dutyMaxCalcosAE - (int) dutyMaxCalcosAE) * 60);
                dutyMaxVal.setText(String.format("%02d", psvMaxHora) + ":" + String.format("%02d", (int) psvMaxMin));
                dutyMaxVal.setVisibility(View.VISIBLE);
                dutyMaxBlock.setText(String.format("%02d", dutyMaxCalcosH) + ":" + String.format("%02d", (int) dutyMaxCalcosM));
                dutyMaxBlock.setVisibility(View.VISIBLE);
                dutyMaxBlockAE.setText(String.format("%02d", dutyMaxCalcosHAE) + ":" + String.format("%02d", (int) dutyMaxCalcosMAE));
                dutyMaxBlockAE.setVisibility(View.VISIBLE);
            }
        });

        imageViewHelpMaxDuty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(CrewRest.this).create();
                alertDialog.setTitle("Unforeseen ... Duty Extension");
                alertDialog.setMessage(Html.fromHtml("<b>"+"ORO.FTL.205 "+
                        "(f) Unforeseen"+"</b>"+" circumstances in flight operations" +
                        " — "+"<b>"+"Commander’s discretion"+"</b>" + "<br>"+ "<br>"+
                        "(1) The maximum daily FDP"+"<b>"+" may not be increased by more than 2 hours"+"</b>"+"...." + "<br>" +
                        "(3) The Commander"+"<b>"+" shall consult all crew members"+"</b>"+" on their alertness levels before deciding...."+ "<br>"+
                        "<br>" + "<b>" + "AMC1 ORO.FTL.205(f) FDP"+ "<br>" +"</b>" +
                        "(a) The exercise of Commander’s discretion "+"<b>"+"should be considered exceptional and should "
                        + "be avoided at home base and/or company hubs where standby or reserve crew members should be available."+"</b>"+ "<br>"+
 //                       "(5) Where the increase of an FDP or reduction of a rest period "+"<b>"+"exceeds 1 hour, a copy"+"</b>"+" of the report,"
//                        + "..., shall be sent by the operator" +
//                                "to the competent authority "+"<b>"+"not later than 28 days"+"</b>"+" after the event."
                        "<br>"+"<b>"+"Dec. Lei 139/04 Artigo 14º" +"</b>"+"<br>"+"2 - Sempre que o PSV exceder em mais de "+"<b>"+
                         "30 minutos"+ "</b>" + " os limites constantes.... o Comandante deve apresentar ao operador um relatório justificativo."+ "<br>" +
                        "4 - O período de repouso subsequente deve ser acrescido"+"<b>"+" do dobro "
                        +"</b>"+"do tempo em que o PSV exceder os limites..." +"<br>"));
                // Alert dialog button
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Alert dialog action goes here
                                // onClick button code here
                                dialog.dismiss();// use dismiss to cancel alert dialog
                            }
                        });
                alertDialog.show();
            }
        });

        imageViewHelpExtension.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(CrewRest.this).create();
                alertDialog.setTitle("Scheduled Duty Extension");
                alertDialog.setMessage(Html.fromHtml("<b>"+"ORO.FTL.205 (d)"+"</b>"+"<br>"+
                        "(1) The maximum daily FDP may be extended by up to "+"<b>"+"1 hour"+ "</b>"+ " not more than"+"<b>"+" twice "
                        + "</b>"+"in any "+"<b>"+"7 consecutive days"+"</b>"+". In that case:" +"<br>"+
                        "(i) the minimum pre-flight and post-filght rest periods shall be increased by "+"<b>"+"2 hours;"+"</b>"+"or"+
                        "<br>"+ "(ii) the post-flight rest period shall be increased by"+"<b>"+" 4 hours"+"</b>" +
                        "<br>"+"(3) The use of extensions"+"<b>"+" shall be planned"+"</b>"+" in advance, and shall be "+"<b>"+"limited"+"</b>"+" to a maximum of:"+"<br>"+
                        "(i)"+"<b>"+" 5 sectors"+ "</b>"+" when the WOCL is "+ "<b>"+"not encroached"+"</b>"+"; or"+"<br>"+
                        "(ii)"+"<b>"+" 4 sectors"+ "</b>"+" when the WOCL is "+ "<b>"+"not encroached"+"</b>"+" by "+ "<b>"+"2 hours or less"+"</b>"+";or"+"<br>"+
                        "(iii)"+"<b>"+" 2 sectors"+ "</b>"+" when the WOCL is "+ "<b>"+"not encroached"+"</b>"+" by "+"<b>"+"more than 2 hours"+"</b>"));
                // Alert dialog button
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Alert dialog action goes here
                                // onClick button code here
                                dialog.dismiss();// use dismiss to cancel alert dialog
                            }
                        });
                alertDialog.show();
            }
        });

        imageViewHelpMaxDutyAE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(CrewRest.this).create();
                alertDialog.setTitle("Limitação e Salvaguarda quando em WOCL");
                alertDialog.setMessage(Html.fromHtml("<b>"+"Cláusula 23ª"+"</b>"+"<br>"+
                        "1. Um Piloto não pode efectuar um período de "+"<b>"+"trabalho"+ "</b>"+ " que inclua o WOCL, no todo ou em parte,"
                        +" mais de "+  "<b>"+ "2 vezes" + "</b>"+" em cada "+"<b>"+"7 dias consecutivos de trabalho" +  "</b>" + "....." +"<br>"+
                        "2. Se o período de trabalho de um Piloto incluir o WOCL, no todo ou em parte, esse Piloto não poderá efectuar mais do que "+
                        "<b>"+"3 aterragens em funções."+"</b>"+
                        "<br>"+ "3. Quando a"+"<b>"+" apresentação"+"</b>" + " de um Piloto acontecer no WOCL, o limite máximo de PSV será de "+ "<b>" +"7 horas." + "</b>" +
                        "<br>"+"4. Os limites previstos "+"<b>"+" nos números anteriores"+"</b>"+" em caso de "+"<b>"+"irregularidade operacional"+"</b>"+
                        ", devem ceder à aplicação da lei em cada momento em vigor, com o limite " +"<b>"+"máximo de 9 horas." +"</b>"));
                // Alert dialog button
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Alert dialog action goes here
                                // onClick button code here
                                dialog.dismiss();// use dismiss to cancel alert dialog
                            }
                        });
                alertDialog.show();
            }
        });
    }

    private void showdialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.custom_dialog);
        dialog.setTitle("Disclaimer");
        Button dialogButton = (Button) dialog.findViewById(R.id.button1);
        dialogcb= (CheckBox) dialog.findViewById(R.id.checkBox1);
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accepted = dialogcb.isChecked();
                SharedPreferences.Editor edit=prefs.edit();
                edit.putBoolean("show_again",!accepted);
                edit.commit();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        sectores = parent.getItemAtPosition(position).toString();
        sectores = sectores.substring(0, 1);
        nsectores = Integer.parseInt(sectores);
        if (nsectores == 1) {
            nsectores = 0;
        } else {
            nsectores = nsectores - 2;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast.makeText(CrewRest.this,
                "Tem de seleccionar o número de sectores", Toast.LENGTH_LONG).show();
    }
}
